# Contains utility functions
# new_path_finding/core/utils.py
import queue
import logging

logger = logging.getLogger(__name__)

def clear_queue(*queues):
    """
    주어진 큐들을 비웁니다.
    """
    for q in queues:
        while not q.empty():
            try:
                q.get_nowait()
                logger.debug(f"🗑️ Cleared item from queue: {q}")
            except queue.Empty:
                logger.debug(f"Queue {q} is empty.")
                pass
            except Exception as e:
                logger.error(f"❗ Error clearing queue {q}: {e}")