# Contains YOLO model processing logic
# new_path_finding/core/yolo_processor.py
from ultralytics import YOLO
import logging

logger = logging.getLogger(__name__)

def yolo_worker(yolo_input_q, yolo_output_q):
    """
    YOLO 모델을 로드하고 이미지 감지 작업을 처리하는 워커 함수.
    yolo_input_q에서 이미지를 받아 YOLO로 추론하고, 결과를 yolo_output_q에 넣습니다.
    """
    try:
        model = YOLO("yolov8n_test.pt").to("cuda")
        logger.info("✅ YOLOv8 model loaded successfully.")
    except Exception as e:
        logger.error(f"❌ Failed to load YOLO model: {e}")
        return 

    while True:
        try:
            image = yolo_input_q.get()
            results = model(image, verbose=False)
            detections = results[0].boxes.data.cpu().numpy().tolist()
            yolo_output_q.put(detections)
            logger.debug("📸 Image processed by YOLO, detections sent.")
        except Exception as e:
            logger.error(f"❗ Error in YOLO worker: {e}")
            continue