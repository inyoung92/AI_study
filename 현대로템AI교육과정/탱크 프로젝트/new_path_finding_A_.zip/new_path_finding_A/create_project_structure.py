# create_project_structure.py
import os

def create_folders_and_files():
    base_dir = "new_path_finding"
    
    os.makedirs(base_dir, exist_ok=True)
    
    with open(os.path.join(base_dir, "__init__.py"), "w") as f:
        pass 
    
    # main.py 파일 생성
    with open(os.path.join(base_dir, "main.py"), "w") as f:
        f.write("# Main Flask application\n")

    # config.py 파일 생성
    with open(os.path.join(base_dir, "config.py"), "w") as f:
        f.write("# Contains application settings and constants\n")

    core_dir = os.path.join(base_dir, "core")
    os.makedirs(core_dir, exist_ok=True)
    with open(os.path.join(core_dir, "__init__.py"), "w") as f:
        pass
    with open(os.path.join(core_dir, "action_controller.py"), "w") as f:
        f.write("# Contains action worker logic\n")
    with open(os.path.join(core_dir, "yolo_processor.py"), "w") as f:
        f.write("# Contains YOLO model processing logic\n")
    with open(os.path.join(core_dir, "utils.py"), "w") as f:
        f.write("# Contains utility functions\n")

    print(f"Project structure '{base_dir}/' created successfully!")
    print("Please copy and paste the provided code snippets into their respective files.")

if __name__ == "__main__":
    create_folders_and_files()