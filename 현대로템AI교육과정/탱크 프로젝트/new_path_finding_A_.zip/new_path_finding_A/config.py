# Contains application settings and constants
# new_path_finding/config.py

# YOLOv8 감지 대상 클래스 정의
target_classes = {
    0: "Car",
    1: "Rock",
    2: "Wall",
    3: "E_Tank",
    4: "Human",
    5: "Mine"
}

# 로깅 파일 이름
LOG_FILE_NAME = 'tank_simulation.log'

# 초기화 설정 (init 엔드포인트에서 반환되는 값)
init_config = {
    "startMode": "start",  # Options: "start" or "pause"
    "blStartX": 60,  #Blue Start Position 60
    "blStartY": 10,
    "blStartZ": 27.23, # 27.23
    "rdStartX": 59, #Red Start Position
    "rdStartY": 10,
    "rdStartZ": 280,
    "trackingMode": True,
    "detactMode": False,
    "logMode": True,
    "enemyTracking": False,
    "saveSnapshot": False,
    "saveLog": False,
    "saveLidarData": False,
    "lux": 30000
}

# --- A* Pathfinding 관련 설정 추가 ---
MAP_WIDTH = 300.0 # 맵의 월드 좌표계 상의 너비 (예: X축 범위)
MAP_HEIGHT = 300.0 # 맵의 월드 좌표계 상의 높이 (예: Z축 범위)
GRID_SIZE = 5.0 # A* 알고리즘의 그리드 셀 크기 (미터)

# 장애물 관련 설정 (현재는 빈 리스트로, 추후 시뮬레이터에서 정보 수신)
# 예시: [{"x": 100, "z": 100, "radius": 10}]
INITIAL_OBSTACLES = [] 


# 기타 전역 설정들을 여기에 추가할 수 있습니다.