# new_path_finding/main.py (수정)
from flask import Flask, request, jsonify
from multiprocessing import Process, Queue
from PIL import Image
import numpy as np
from io import BytesIO
import logging
import queue
import time
import copy 
import threading # 스레드 사용을 위해 임포트

from core.action_controller import action_worker, normalize_angle
from core.yolo_processor import yolo_worker
from core.utils import clear_queue 
from config import target_classes, LOG_FILE_NAME, init_config, MAP_WIDTH, MAP_HEIGHT, GRID_SIZE, INITIAL_OBSTACLES

app = Flask(__name__)

# 큐 생성
yolo_input_queue = Queue()
yolo_output_queue = Queue()

action_input_queue = Queue()
action_output_queue = Queue()

detect_input_queue = Queue()
init_input_queue = Queue()
hit_input_queue = Queue()
collision_input_queue = Queue()

info_input_queue = Queue() 
info_output_queue = Queue() 

path_request_queue = Queue() 
path_result_queue = Queue() 
obstacle_queue = Queue() 

# --- 로깅 설정 ---
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

file_handler = logging.FileHandler(LOG_FILE_NAME, mode='a', encoding='utf-8')
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(processName)s - %(message)s'))
logger.addHandler(file_handler)

stream_handler = logging.StreamHandler()
stream_handler.setLevel(logging.INFO)
stream_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(processName)s - %(message)s'))
logger.addHandler(stream_handler)

werkzeug_log = logging.getLogger('werkzeug')
werkzeug_log.setLevel(logging.WARNING)
# --- 로깅 설정 끝 ---

# --- 웨이포인트 관련 전역 변수 ---
# A* 경로를 주력으로 사용할 것이므로, 초기 웨이포인트는 여기서는 사용하지 않음
# target_waypoints = [] # 제거하거나, 디버깅 목적으로만 남겨둡니다.
current_waypoint_index = -1 
current_path = [] # A* 알고리즘으로 계산된 경로를 저장할 리스트

# 전차의 목표를 설정하고 action_worker에게 전달하는 함수
def set_tank_target(x, z):
    logger.info(f"🎯 목표 설정 (main): x={x:.2f}, y=8.00, z={z:.2f}") # y값은 고정으로 가정
    action_input_queue.put({"destination": {"x": x, "y": 8.002197, "z": z}})

# 다음 웨이포인트를 로드하는 함수 (A* 경로에서 다음 노드를 가져오도록 수정)
def load_next_waypoint():
    global current_path, current_waypoint_index

    # A* 경로가 있다면 그 경로의 다음 노드를 웨이포인트로 사용
    if current_path and current_waypoint_index + 1 < len(current_path):
        current_waypoint_index += 1
        next_wp = current_path[current_waypoint_index]
        set_tank_target(next_wp['x'], next_wp['z'])
        logger.info(f"➡️ A* 경로 다음 노드 로드: {current_waypoint_index + 1}/{len(current_path)} - ({next_wp['x']:.2f}, {next_wp['z']:.2f})")
        return True
    else:
        # 경로가 없거나 마지막 노드에 도달했을 때
        if current_path: # A* 경로의 마지막 노드에 도달한 경우
            logger.info("✅ A* 경로의 마지막 노드에 도달했습니다. 이동을 종료합니다.")
        else: # 경로가 처음부터 비어있거나 이미 완료된 경우
            logger.info("📍 현재 경로가 비어있거나 이미 완료되었습니다. 새로운 경로를 요청해야 합니다.")

        action_input_queue.put({"destination": "STOP"})
        current_path = [] # 경로 완료 후 초기화
        current_waypoint_index = -1
        return False

# 백그라운드에서 action_worker로부터의 상태 업데이트를 처리하는 함수
def process_action_worker_status():
    global current_path, current_waypoint_index
    while True:
        try:
            status_data = info_output_queue.get(timeout=1.0) 
            if status_data.get("status") == "arrived_at_waypoint":
                logger.info("action_worker로부터 웨이포인트 도달 신호 수신. 다음 웨이포인트 로드 시도.")
                load_next_waypoint() 
            elif status_data.get("status") == "initialized":
                logger.info("action_worker 초기화 완료 신호 수신.")
                # Action Worker가 초기화 완료 후 첫 경로 요청을 보내는 것이 더 자연스러움
                # 여기서는 main에서 강제로 첫 경로 요청을 보낼 수도 있으나,
                # 시뮬레이터에서 /set_destination을 호출하는 것이 일반적
            elif status_data.get("status") == "path_calculated":
                received_path = status_data.get("path")
                if received_path:
                    current_path = received_path
                    current_waypoint_index = -1 # 새로운 경로가 왔으니 인덱스 초기화
                    logger.info(f"A* 경로 계산 완료 및 수신. 경로 길이: {len(current_path)}")
                    load_next_waypoint() # 새 경로의 첫 번째 웨이포인트 로드
                else:
                    logger.warning("action_worker로부터 빈 경로 수신. 이동 불가.")
                    action_input_queue.put({"destination": "STOP"})
            # 다른 상태 메시지 처리
        except queue.Empty:
            pass 
        except Exception as e:
            logger.error(f"Error processing action_worker status: {e}")
        time.sleep(0.01) # 너무 바쁘지 않게 잠시 대기

# --- Flask 엔드포인트들 ---
@app.route('/detect', methods=['POST'])
def detect():
    image = request.files.get('image')
    if not image:
        return jsonify({"error": "No image received"}), 400
    pil_image = Image.open(BytesIO(image.read()))
    np_image = np.array(pil_image)
    
    yolo_input_queue.put(np_image) 
    detections = yolo_output_queue.get() 
    
    detect_input_queue.put(detections)
    filtered_results = []
    for box in detections:
        class_id = int(box[5])
        if class_id in target_classes: 
            filtered_results.append({
                'className': target_classes[class_id],
                'bbox': [float(coord) for coord in box[:4]],
                'confidence': float(box[4]),
                'color': '#00FF00',
                'filled': False,
                'updateBoxWhileMoving': False
            })

    return jsonify(filtered_results)

@app.route('/info', methods=['POST'])
def info():
    data = request.get_json(force=True)
    if not data:
        return jsonify({"error": "No JSON received"}), 400
    
    clear_queue(info_input_queue) 
    info_input_queue.put(data)

    log_data = copy.deepcopy(data) 
    if "lidarPoints" in log_data:
        del log_data["lidarPoints"]
    logger.debug(f"📨 /info data received (lidarPoints excluded): {log_data}")

    return jsonify({"status": "OK", "message": "Info received, processing..."})

@app.route('/get_action', methods=['POST']) 
def get_action():
    try:
        latest_action = None
        while not action_output_queue.empty():
            latest_action = action_output_queue.get_nowait()
        
        if latest_action:
            logger.debug(f"📤 /get_action: {latest_action}")
            return jsonify(latest_action)
        else:
            default_action = {
                "moveWS": {"command": "", "weight": 0.0},
                "moveAD": {"command": "", "weight": 0.0},
                "turretQE": {"command": "", "weight": 0.0},
                "turretRF": {"command": "", "weight": 0.0},
                "fire": False
            }
            return jsonify(default_action)
    except queue.Empty:
        default_action = {
            "moveWS": {"command": "", "weight": 0.0},
            "moveAD": {"command": "", "weight": 0.0},
            "turretQE": {"command": "", "weight": 0.0},
            "turretRF": {"command": "", "weight": 0.0},
            "fire": False
        }
        logger.debug("⏳ /get_action: 액션 큐 비어있음, 기본 액션 반환.")
        return jsonify(default_action)


@app.route('/update_bullet', methods=['POST'])
def update_bullet():
    data = request.get_json()
    if not data:
        return jsonify({"status": "ERROR", "message": "Invalid request data"}), 400
    hit_input_queue.put(data)
    return jsonify({"status": "OK", "message": "Bullet impact data received"})

@app.route('/set_destination', methods=['POST'])
def set_destination():
    data = request.get_json()
    if not data or "destination" not in data:
        return jsonify({"status": "ERROR", "message": "Missing destination data"}), 400

    try:
        x, y, z = map(float, data["destination"].split(","))
        
        path_request_queue.put({
            "request_type": "find_path",
            "target_pos": {"x": x, "z": z}
        })
        logger.info(f"🎯 수동 목표 설정 (A* 요청): x={x:.2f}, y={y:.2f}, z={z:.2f}")
        return jsonify({"status": "OK", "message": "Pathfinding request sent to action worker"})
    except Exception as e:
        return jsonify({"status": "ERROR", "message": f"Invalid format: {str(e)}"}), 400

@app.route('/update_obstacle', methods=['POST'])
def update_obstacle():
    data = request.get_json()
    if not data:
        return jsonify({'status': 'error', 'message': 'No data received'}), 400
    
    obstacle_queue.put(data)
    logger.debug(f"🪨 Obstacle Data received and sent to action worker: {data}")
    return jsonify({'status': 'success', 'message': 'Obstacle data received and forwarded'})

@app.route('/collision', methods=['POST']) 
def collision():
    data = request.get_json()
    if not data:
        return jsonify({'status': 'error', 'message': 'No collision data received'}), 400
    collision_input_queue.put(data)

    object_name = data.get('objectName')
    position = data.get('position', {})
    x = position.get('x')
    y = position.get('y')
    z = position.get('z')
    logger.info(f"🚨 충돌 감지: Object='{object_name}', Position=({x:.2f}, {y:.2f}, {z:.2f})")
    return jsonify({'status': 'success', 'message': 'Collision data received'})

@app.route('/init', methods=['GET'])
def init_simulation_with_waypoints():
    global current_path, current_waypoint_index # target_waypoints는 사용하지 않음
    
    current_waypoint_index = -1 
    current_path = [] # A* 경로도 초기화
    
    logger.info(f"🛠️ Simulation initialized via GET /init. Sending init signal to action_worker.")
    init_data = {
        "config": init_config,
        "map_info": {
            "map_width": MAP_WIDTH,
            "map_height": MAP_HEIGHT,
            "grid_size": GRID_SIZE,
            "initial_obstacles": INITIAL_OBSTACLES 
        }
    }
    init_input_queue.put(init_data) 
    
    # /init 시점에 경로 요청을 바로 보내지 않습니다.
    # action_worker가 초기화되고 현재 위치를 받은 후,
    # /set_destination을 통해 외부에서 목표를 설정해야 경로 탐색이 시작됩니다.
    # 또는 action_worker가 초기화 완료 신호를 보낸 후,
    # action_worker 내부에서 (예: init_config의 target_pos를 활용하여) 첫 경로를 요청하도록 할 수 있습니다.

    return jsonify(init_config)

@app.route('/start', methods=['GET'])
def start():
    logger.info("🚀 /start command received")
    return jsonify({"control": ""})

if __name__ == '__main__':
    # Flask 앱 실행 전에 process_action_worker_status 스레드 시작
    status_thread = threading.Thread(target=process_action_worker_status, daemon=True)
    status_thread.start()
    
    yolo_proc = Process(target=yolo_worker, args=(yolo_input_queue, yolo_output_queue))
    action_proc = Process(target=action_worker, args=(
        action_input_queue, action_output_queue,
        hit_input_queue, detect_input_queue,
        info_input_queue, info_output_queue,
        init_input_queue, collision_input_queue,
        path_request_queue, path_result_queue, 
        obstacle_queue 
    ))
    yolo_proc.start()
    action_proc.start()

    app.run(host='0.0.0.0', port=5008, threaded=True)